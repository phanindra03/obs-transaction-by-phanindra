package com.ob.dao;

public interface IQueryMapper {

	String CUSTOMER_INSERT_QRY ="insert into customer values(?,?,?,?,?,SYSDATE,jdbc1_seq1.NEXTVAL)" ;
	String USER_INSERT_QRY ="insert into accountmaster values" ;
	
	String Update_PASSWORD="update user_table set loginPassword=? where user_id=?";
	
	String RETRIVE_PAYEE_ID="select payee_account_id,nickname from payee where account_id=?";
	String PAYEE_INSERT_QRY = "insert into payee values(?,?,?)";
	String RETRIVE_PAYEE_ACCOUNTID = "SELECT count(*) from Payee WHERE payeeAccountId = ?";
	String RETRIVE_TRANSACTION_PWD = "select transactionpwd from user_table where account_id=?";
	String INSERT_TRANSACTION = "insert into transaction values(?,?,SYSDATE,?,?,?)";
	String INSERT_FUND_TRANSFER = "insert into fund_transfer values(?,?,?,SYSDATE,?)";
	String UPDATE_PAYEE_ACCOUNTBAL = "update accountmaster set accountbal=? where account_id=?";
	String RETRIVE_ACCOUNT_BAL = "select accountbal from accountmaster where accountId=?";
	

}
